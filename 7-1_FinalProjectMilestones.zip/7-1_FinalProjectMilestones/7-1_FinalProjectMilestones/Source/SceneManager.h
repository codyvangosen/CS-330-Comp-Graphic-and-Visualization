///////////////////////////////////////////////////////////////////////////////
// scenemanager.h
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including the shader settings.
 ***********************************************************/
class SceneManager
{
public:
	// constructor
	SceneManager(ShaderManager* pShaderManager);
	// destructor
	~SceneManager();

	// Structure for storing texture information
	struct TEXTURE_INFO
	{
		std::string tag = "";  // Default empty string
		uint32_t ID = 0;        // Default texture ID to 0
	};

	// Structure for object material properties
	struct OBJECT_MATERIAL
	{
		glm::vec3 diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);  // Default color white
		glm::vec3 specularColor = glm::vec3(0.5f, 0.5f, 0.5f); // Default moderate shine
		float shininess = 32.0f;  // Default shininess level
		std::string tag = "";     // Default empty string
	};

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// pointer to basic shapes object
	ShapeMeshes* m_basicMeshes;
	// total number of loaded textures
	int m_loadedTextures = 0;  // Ensure this is initialized
	// loaded textures info
	TEXTURE_INFO m_textureIDs[16];
	// defined object materials
	std::vector<OBJECT_MATERIAL> m_objectMaterials;

	// load texture images and convert to OpenGL texture data
	bool CreateGLTexture(const char* filename, std::string tag);
	// bind loaded OpenGL textures to slots in memory
	void BindGLTextures();
	// free the loaded OpenGL textures
	void DestroyGLTextures();
	// find a loaded texture by tag
	int FindTextureID(std::string tag);
	int FindTextureSlot(std::string tag);
	// find a defined material by tag
	bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

	// set transformation values into the transform buffer
	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ,
		glm::vec3 offset = glm::vec3(0.0f, 0.0f, 0.0f));

	// set the color values into the shader
	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// set the texture data into the shader
	void SetShaderTexture(std::string textureTag);
	// set the UV scale for texture mapping
	void SetTextureUVScale(float u, float v);
	// set the object material into the shader
	void SetShaderMaterial(std::string materialTag);

public:
	// The following methods are for students to customize their 3D scenes
	void PrepareScene();
	void RenderScene();
	// Function to load scene textures
	void LoadSceneTextures();
	// Function to setup lighting for the scene
	void SetupSceneLights();
	// Function to define object materials
	void DefineObjectMaterials();
};